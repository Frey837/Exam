string = 'artqmgrigorqev@gmail.com'
if ('@' in string) and ('.com' in string) or ('.lv' in string):
    print(True)
else:
    print(False)